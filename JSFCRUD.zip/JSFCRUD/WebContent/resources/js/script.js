window.onload = function()
{
	alert("Testo");
}